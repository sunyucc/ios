//
//  HomeDetailVC.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "HomeDetailVC.h"

#import "Escape.h"

#import "NJKWebViewProgressView.h"
#import "NJKWebViewProgress.h"

@interface HomeDetailVC () <UIWebViewDelegate, NJKWebViewProgressDelegate>

{
    UIWebView *_webView;
    UIBarButtonItem *_backBarBtn;
    UIBarButtonItem *_closeBarBtn;
    
    //webView 的进度条
    NJKWebViewProgressView *_webViewProgressView;
    NJKWebViewProgress *_webViewProgress;
    
}

@end

@implementation HomeDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.interactivePopGestureRecognizer.delegate = (id)self;
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 64, sWidth, sHeight-64)];
    _webView.delegate = self;
    _webView.scalesPageToFit = YES;
    [self.view addSubview:_webView];

    [self setupProgressView];
    [self setupBackAndCloseBtn];

    NSString *urlStr = nil;
    NSString *modelStr = nil;
    if (self.isADVC == 1) {//广告图
        modelStr = self.adModel.xwdz;
        
    }else if(self.isADVC == 2){//首页模块
        NSString *nameStr = [Escape escape:self.moduleModel.mkmc];

        if ([self.moduleModel.qqdz containsString:@"info.html"]) {
            modelStr = [NSString stringWithFormat:@"%@?title=%@&target=%@", self.moduleModel.qqdz, nameStr, self.moduleModel.yydz];
        }else{
            modelStr = self.moduleModel.qqdz;
        }
        
    }else if (self.isADVC == 3){//事项中心
        
    NSString *nameStr = [Escape escape:self.matterModel.sxmc];
    modelStr = [NSString stringWithFormat:@"%@?bmid=%@&sxid=%@&zn=%@&yy=%@&sb=%@&sxmc=%@&sxywdl=%@&sxywlb=%@", self.detailStr, self.matterModel.zdBsckid, self.matterModel.sxid, self.matterModel.zn, self.matterModel.yy, self.matterModel.sb, nameStr, self.matterModel.sxywdl, self.matterModel.sxywlb];
        
    }else if (self.isADVC == 4){//龙警微博
        modelStr = HomePage_SinaWeibo;
        
    }else if (self.isADVC == 5){//龙警要闻
        modelStr = HomePage_PoliceNews;
        
    }else if (self.isADVC == 6){//智能咨询
        modelStr = self.detailStr;
    }
    
    if (![modelStr containsString:@"http://"]) {
        urlStr = [@"http://" stringByAppendingString:modelStr];
    }else{
        
        urlStr = modelStr;
    }
    
    [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:modelStr]]];
    
}

//防止进度条没加载完产生的一直显示的bug
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_webViewProgressView removeFromSuperview];
}

//进度条
- (void)setupProgressView
{
    _webViewProgress = [[NJKWebViewProgress alloc] init];
    _webView.delegate = _webViewProgress;
    _webViewProgress.webViewProxyDelegate = self;
    _webViewProgress.progressDelegate = self;
    
    CGRect navBounds = self.navigationController.navigationBar.bounds;
    CGRect barFrame = CGRectMake(0,
                                 navBounds.size.height - 2,
                                 navBounds.size.width,
                                 2);
    _webViewProgressView = [[NJKWebViewProgressView alloc] initWithFrame:barFrame];
    _webViewProgressView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    [_webViewProgressView setProgress:0 animated:YES];
    [self.navigationController.navigationBar addSubview:_webViewProgressView];

}

#pragma mark - NJKWebViewProgressDelegate
-(void)webViewProgress:(NJKWebViewProgress *)webViewProgress updateProgress:(float)progress
{
    [_webViewProgressView setProgress:progress animated:YES];
    self.title = [_webView stringByEvaluatingJavaScriptFromString:@"document.title"];
}

- (void)setupBackAndCloseBtn
{
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    backBtn.frame = CGRectMake(0, 0, 50, 40);
    backBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    // 让按钮内部的所有内容左对齐
    backBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    // 让按钮的内容往左边偏移10
    backBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -20, 0, 0);
    //    backBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -20, 0, 0);
    [backBtn setImage:[UIImage imageNamed:@"nav_back"] forState:UIControlStateNormal];
    [backBtn setTitle:@"返回" forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(backBtnClick) forControlEvents:UIControlEventTouchUpInside];
    _backBarBtn = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    
    self.navigationItem.leftBarButtonItem = _backBarBtn;
    
    UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    closeBtn.frame = CGRectMake(0, 0, 40, 40);
    closeBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    
    [closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
    [closeBtn addTarget:self action:@selector(closeBtnClick) forControlEvents:UIControlEventTouchUpInside];
    
    _closeBarBtn = [[UIBarButtonItem alloc] initWithCustomView:closeBtn];
    
}

- (void)backBtnClick
{
    if ([_webView canGoBack]) {
        [_webView goBack];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)closeBtnClick
{
    [self.navigationController popViewControllerAnimated:YES];
}


//页面加载完成之后调用
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSString *currentUrlStr = [NSString stringWithFormat:@"%@", webView.request.URL];
    
    if (webView.canGoBack) {
        self.navigationItem.leftBarButtonItems = @[_backBarBtn, _closeBarBtn];
    }else{
        self.navigationItem.leftBarButtonItems = @[_backBarBtn];
    }
    
    /**
     首页H5 url ＝ http://yingyong.hljga.gov.cn/index.html
     事项中心H5 url ＝ http://yingyong.hljga.gov.cn/sxzx/index.html
     提交成功后会跳转到这个两个页面。就直接返回
     */
    
    if ([currentUrlStr containsString:@"yingyong.hljga.gov.cn/index.html"] || [currentUrlStr containsString:@"yingyong.hljga.gov.cn/sxzx/index.html"]) {//提交成功，直接关闭
        [self.navigationController popViewControllerAnimated:YES];
    }
}

//webview加载失败
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    if([error code] == NSURLErrorCancelled)
    {
        return;
    }
        
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
    [SVProgressHUD showErrorWithStatus:@"加载失败"];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
    });
}

@end
