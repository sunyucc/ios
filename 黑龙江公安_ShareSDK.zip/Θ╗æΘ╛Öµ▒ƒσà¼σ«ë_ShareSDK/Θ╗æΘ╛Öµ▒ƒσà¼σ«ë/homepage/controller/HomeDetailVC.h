//
//  HomeDetailVC.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ADPhotoModel.h"
#import "ModuleModel.h"
#import "MatterCenterModel.h"

@interface HomeDetailVC : UIViewController

/*
 H5页面展示页面
 用于首页模块、龙警微博、龙警要闻、广告轮播图、智能咨询和事项中心的二级页面
 */


/**
 int类型
 1 = 广告页
 2 = 主页cell
 3 = 事项中心cell
 4 = 龙警微博
 5 = 龙警要闻
 6 = 智能咨询
 */
@property (nonatomic, assign) int isADVC;

@property (nonatomic, copy) NSString *detailStr; //事项中心详情页面对应的H5页面的URL

@property (nonatomic, strong) ADPhotoModel *adModel;
@property (nonatomic, strong) ModuleModel *moduleModel;
@property (nonatomic, strong) MatterCenterModel *matterModel;

@end
