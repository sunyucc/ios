//
//  ModuleModel.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "ModuleModel.h"

@implementation ModuleModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    

    
}

@end
