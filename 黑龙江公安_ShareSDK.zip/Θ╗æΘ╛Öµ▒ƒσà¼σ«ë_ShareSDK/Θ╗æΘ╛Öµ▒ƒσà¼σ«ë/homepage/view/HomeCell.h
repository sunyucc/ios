//
//  HomeCell.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/17.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 首页中每个功能模块的cell，即每个格子。继承于UICollectionViewCell
 */

@interface HomeCell : UICollectionViewCell

@property (nonatomic, strong) UILabel *titleLab;
@property (nonatomic, strong) UIImageView *iconView;

@property (nonatomic, strong) UIView *topLine;
@property (nonatomic, strong) UIView *bottomLine;

@property (nonatomic, strong) UIView *leftLine;
@property (nonatomic, strong) UIView *rightLine;


@end
