//
//  NormolBtn.h
//  黑龙江公安
//
//  Created by administrator on 16/12/4.
//  Copyright © 2016年 wdykqios. All rights reserved.
//



#import <UIKit/UIKit.h>

/*
 使用在首页中，警务资讯、微博、分享的按钮。
 重新布局了按钮中图片和文字的位置。
 */

@interface NormolBtn : UIButton

@end
