//
//  NormolBtn.m
//  黑龙江公安
//
//  Created by administrator on 16/12/4.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "NormolBtn.h"

@implementation NormolBtn

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.font = [UIFont systemFontOfSize:15];
        [self setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        self.imageView.contentMode = UIViewContentModeScaleAspectFill;
        
    }
    
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat btnWidth = self.frame.size.width;
    CGFloat btnHeigth = self.frame.size.height;
    
    self.imageView.frame = CGRectMake((btnWidth-60)/2, 10, 60, 60);
    self.titleLabel.frame = CGRectMake(0, btnHeigth-30, btnWidth, 30);
    
}

@end
