//
//  MatterVCTableCell.h
//  黑龙江公安
//
//  Created by administrator on 16/12/24.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface MatterVCTableCell : UITableViewCell

@property (strong, nonatomic) UILabel *contentLab;
@property (strong, nonatomic) UILabel *numberLab;

@property (nonatomic, strong) UIImageView *arrowIV;

@property (nonatomic, assign) BOOL showNumber;

@end
