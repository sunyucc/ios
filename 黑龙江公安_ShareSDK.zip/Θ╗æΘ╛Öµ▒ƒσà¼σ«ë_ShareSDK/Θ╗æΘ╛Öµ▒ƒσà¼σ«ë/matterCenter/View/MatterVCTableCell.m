//
//  MatterVCTableCell.m
//  黑龙江公安
//
//  Created by administrator on 16/12/24.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "MatterVCTableCell.h"

@implementation MatterVCTableCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        
        self.arrowIV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
        self.arrowIV.center = CGPointMake(sWidth-30, self.contentView.center.y);
        self.arrowIV.image = [UIImage imageNamed:@"matterVC_arrow"];
        [self.contentView addSubview:self.arrowIV];

        self.numberLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 50, 20)];
        self.numberLab.textAlignment = NSTextAlignmentCenter;
        self.numberLab.font = [UIFont systemFontOfSize:15];
        self.numberLab.textColor = [UIColor lightGrayColor];
        self.numberLab.center = CGPointMake(sWidth-60, self.contentView.center.y);
        [self.contentView addSubview:self.numberLab];
        
        self.contentLab = [[UILabel alloc] initWithFrame:CGRectMake(5, 5, sWidth-95, self.contentView.frame.size.height-10)];
        self.contentLab.font = [UIFont systemFontOfSize:16];
        self.contentLab.numberOfLines = 0;
        [self.contentView addSubview:self.contentLab];

    }
    return self;
}

@end
