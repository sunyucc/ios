//
//  MyTabbarBtn.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/18.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "MyTabbarBtn.h"

@implementation MyTabbarBtn

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.font = [UIFont systemFontOfSize:11];
        [self setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        
        [self setTitleColor:[UIColor colorWithRed:0/255.f green:90/255.f blue:180/255.f alpha:1] forState:UIControlStateSelected];
        
        self.imageView.contentMode = UIViewContentModeScaleAspectFill;
        
    }
    
    return self;
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat btnWidth = self.frame.size.width;
    CGFloat btnHeigth = self.frame.size.height;
    
    self.imageView.frame = CGRectMake((btnWidth-26)/2, 5, 26, 26);
    self.titleLabel.frame = CGRectMake(0, btnHeigth-15, btnWidth, 15);
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
