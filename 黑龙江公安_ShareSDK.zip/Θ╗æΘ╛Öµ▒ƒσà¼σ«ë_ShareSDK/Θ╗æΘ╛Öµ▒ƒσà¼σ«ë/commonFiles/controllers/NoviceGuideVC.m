//
//  NoviceGuideVC.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/16.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "NoviceGuideVC.h"
#import "HLJTabbarcontroller.h"

@interface NoviceGuideVC () <UIScrollViewDelegate>

{
    UIScrollView *_scrollView;
    UIPageControl *_pageCtl;

    UIButton *_dismissBtn;
}

@end

@implementation NoviceGuideVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, sWidth, sHeight)];
    _scrollView.delegate = self;
    _scrollView.pagingEnabled = YES;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.contentSize = CGSizeMake(sWidth*4, 0);
    
    for (int i = 0; i < 4; i++) {
        UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(sWidth*i, 0, sWidth, sHeight)];
        iv.image = [UIImage imageNamed:[NSString stringWithFormat:@"novice_%02d.jpg", i+1]];
        [_scrollView addSubview:iv];
    }
    
    [self.view addSubview:_scrollView];
    
    _pageCtl = [[UIPageControl alloc] initWithFrame:CGRectMake((sWidth-100)/2, sHeight-30, 100, 20)];
    _pageCtl.numberOfPages = 4;
    _pageCtl.currentPageIndicatorTintColor = [UIColor darkGrayColor];
    _pageCtl.pageIndicatorTintColor = [UIColor lightGrayColor];
    _pageCtl.currentPage = 0;
    [self.view addSubview:_pageCtl];
    
    _dismissBtn = [[UIButton alloc] initWithFrame:CGRectMake((sWidth-150)/2, sHeight-100, 150, 35)];
    _dismissBtn.hidden = YES;
    _dismissBtn.backgroundColor = [UIColor grayColor];
    _dismissBtn.layer.masksToBounds = YES;
    _dismissBtn.layer.cornerRadius = 5;
    [_dismissBtn addTarget:self action:@selector(dismissBtnClick) forControlEvents:UIControlEventTouchUpInside];
//    [_dismissBtn setTitle:@"开始使用" forState:UIControlStateNormal];
    [_dismissBtn setBackgroundImage:[UIImage imageNamed:@"GotoLook"] forState:UIControlStateNormal];
    
    [self.view addSubview:_dismissBtn];
}

//结束引导页面
- (void)dismissBtnClick
{
    UIWindow *window = self.view.window;
    HLJTabbarcontroller *main = [[HLJTabbarcontroller alloc] init];
    
    //添加一个缩放效果
    main.view.transform = CGAffineTransformMakeScale(0.2, 0.2);
    [UIView animateWithDuration:0.3 animations:^{
        main.view.transform = CGAffineTransformIdentity;
    }];
    
    window.rootViewController = main;

}

#pragma mark -- scrollView delegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    int page = scrollView.contentOffset.x / sWidth;
    
    if (page == 3) {
        _dismissBtn.hidden = NO;
    }else{
        _dismissBtn.hidden = YES;
    }
    
    _pageCtl.currentPage = page;
}


@end
