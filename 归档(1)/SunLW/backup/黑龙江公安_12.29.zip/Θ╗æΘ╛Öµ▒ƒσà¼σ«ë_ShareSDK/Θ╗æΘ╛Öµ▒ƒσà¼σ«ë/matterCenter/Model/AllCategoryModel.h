//
//  AllCategoryModel.h
//  黑龙江公安
//
//  Created by administrator on 16/11/23.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AllCategoryModel : NSObject


//"zdid": 5,
//"glid": 1,
//"mc": "监管",
//"bm": "05",
//"jp": "jg",
//"qp": "jianguan",
//"scbj": "n",
//"cjsj": "2016-11-14",
//"gxsj": ""

//"zdid": 12,
//"glid": 2,
//"mc": "个人",
//"bm": "01",
//"jp": "gr",
//"qp": "geren",
//"scbj": "n",
//"cjsj": "2016-11-14",
//"gxsj": ""


@property (nonatomic, copy) NSString *zdid;
@property (nonatomic, copy) NSString *glid;
@property (nonatomic, copy) NSString *mc;
@property (nonatomic, copy) NSString *bm;
@property (nonatomic, copy) NSString *jp;
@property (nonatomic, copy) NSString *qp;
@property (nonatomic, copy) NSString *scbj;
@property (nonatomic, copy) NSString *cjsj;
@property (nonatomic, copy) NSString *gxsj;


@end
