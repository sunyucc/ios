//
//  ModuleModel.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <Foundation/Foundation.h>

//"funcid": 10022,
//"tbdz": "http://www.83027110.com/stwx/images/jtyw.png",
//"mkmc": "交警业务",
//"qqdz": "http://www.83027110.com/stwx/jiaojing.html",
//"gnms": "交警业务",
//"scbj": "n",
//"cjsj": "2016-11-26",
//"gxsj": "",
//"mklb": "04",
//"xznr": "",
//"yydz": "",
//"sycs": 0


@interface ModuleModel : NSObject

@property (nonatomic, copy) NSString *funcid;
@property (nonatomic, copy) NSString *tbdz;
@property (nonatomic, copy) NSString *mkmc;
@property (nonatomic, copy) NSString *qqdz;
@property (nonatomic, copy) NSString *gnms;
@property (nonatomic, copy) NSString *scbj;
@property (nonatomic, copy) NSString *cjsj;
@property (nonatomic, copy) NSString *gxsj;
@property (nonatomic, copy) NSString *mklb;

@property (nonatomic, copy) NSString *xznr;
@property (nonatomic, copy) NSString *yydz;
@property (nonatomic, copy) NSString *sycs;

@end
