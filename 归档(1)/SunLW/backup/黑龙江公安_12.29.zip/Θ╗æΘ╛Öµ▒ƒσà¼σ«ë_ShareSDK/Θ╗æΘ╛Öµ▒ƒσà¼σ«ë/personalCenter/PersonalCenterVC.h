//
//  PersonalCenterVC.h
//  黑龙江公安
//
//  Created by administrator on 16/11/25.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTabbarBtn.h"

@interface PersonalCenterVC : UIViewController

@property (nonatomic, copy) NSString *urlStr;
@property (nonatomic, strong) MyTabbarBtn *itemBtn;

@end
