//
//  MyAFNet.h
//  黑龙江公安
//
//  Created by administrator on 16/11/23.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyAFNet : NSObject
/*
 afn下载的类。
 分为get和post下载
 */
+ (void)getData:(NSString *)URLString parameters:(id)parameters success:(void (^) (id responseObject))success failure:(void (^) (NSError *error))failure;

+ (void)postData:(NSString *)URLString parameters:(id)parameters success:(void (^) (id responseObject))success failure:(void (^) (NSError *error))failure;


@end
