//
//  GetGrayPicture.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/18.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GetGrayPicture : NSObject

/*
 把彩色图片变为灰色的类，保持babbar图片颜色的一致
 */

+ (UIImage*)grayscale:(UIImage*)anImage type:(char)type;

@end
