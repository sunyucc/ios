//
//  AppDelegate.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "AppDelegate.h"

#import "HLJTabbarcontroller.h"
#import "NoviceGuideVC.h"
#import "UMMobClick/MobClick.h"


#import <ShareSDK/ShareSDK.h>
#import <ShareSDKConnector/ShareSDKConnector.h>

//腾讯开放平台（对应QQ和QQ空间）SDK头文件
#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterface.h>
//微信SDK头文件
#import "WXApi.h"
//新浪微博SDK头文件
#import "WeiboSDK.h"

#define MyVersionNum 10 //自定义app版本，与服务器中比较，用来判断是非有版本了。弹框显示更新。

@interface AppDelegate ()

@end

@implementation AppDelegate

//友盟移动统计
- (void)umengTrack {
    [MobClick setLogEnabled:NO];
    UMConfigInstance.appKey = @"583bc91465b6d66d49001b27";
    UMConfigInstance.channelId = @"App Store";
    [MobClick startWithConfigure:UMConfigInstance];
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [self umengTrack];
    [self sharSDK];
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    //判断版本号是否与存储的版本号一致
    NSString *versionStr = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *oldVersionStr = [ud objectForKey:@"versionStr"];

    //判断是否是新版本，如果是新版本，就显示引导页面，否则直接进入app
    if (![versionStr isEqualToString:oldVersionStr]) {
        [ud setObject:versionStr forKey:@"versionStr"];
        NoviceGuideVC *guideVC = [[NoviceGuideVC alloc] init];
        self.window.rootViewController = guideVC;
        
    }else{
        HLJTabbarcontroller *rootTC = [[HLJTabbarcontroller alloc] init];
        self.window.rootViewController = rootTC;
    }

    [self.window makeKeyAndVisible];
    
    [self checkUpdate];
    
    return YES;
}

//分享
- (void)sharSDK
{
    [ShareSDK registerApp:@"199931531c2ef"
     
          activePlatforms:@[
                            @(SSDKPlatformTypeSinaWeibo),
                            @(SSDKPlatformTypeWechat),
                            @(SSDKPlatformTypeQQ)]
     
                 onImport:^(SSDKPlatformType platformType)
     {
         switch (platformType)
         {
             case SSDKPlatformTypeWechat:
                 [ShareSDKConnector connectWeChat:[WXApi class]];
                 break;
             case SSDKPlatformTypeQQ:
                 [ShareSDKConnector connectQQ:[QQApiInterface class] tencentOAuthClass:[TencentOAuth class]];
                 break;
             case SSDKPlatformTypeSinaWeibo:
                 [ShareSDKConnector connectWeibo:[WeiboSDK class]];
                 break;
             default:
                 break;
         }
     }
          onConfiguration:^(SSDKPlatformType platformType, NSMutableDictionary *appInfo)
     {
         
         switch (platformType)
         {
             case SSDKPlatformTypeSinaWeibo:
                 //设置新浪微博应用信息,其中authType设置为使用SSO＋Web形式授权
                 [appInfo SSDKSetupSinaWeiboByAppKey:@"17193240"
                                           appSecret:@"722f42d1a78a005746427006f85a629d"
                                         redirectUri:@"http://gafw.hljga.gov.cn"
                                            authType:SSDKAuthTypeBoth];
                 
                 break;
             case SSDKPlatformTypeWechat:
                 [appInfo SSDKSetupWeChatByAppId:@"wxdc0aee40c09ef178"
                                       appSecret:@"7fa9020c751575205ec5a237798423c1"];
                 break;
             case SSDKPlatformTypeQQ:
                 [appInfo SSDKSetupQQByAppId:@"1105792301"
                                      appKey:@"OfbY04VQmeKPE9aM"
                                    authType:SSDKAuthTypeBoth];
                 break;
             default:
                 break;
         }
     }];
}

/**
 检查更新，弹出提示框
 */
- (void)checkUpdate
{
    [MyAFNet getData:AppDelegate_Get_KeyData parameters:nil success:^(id responseObject) {
        
        NSDictionary *needUpdate = responseObject[@"comm"];
        NSString *qzgx = needUpdate[@"qzgx"];
        NSString *sxdjs = needUpdate[@"sxdjs"];
        
        NSDictionary *iosVer = responseObject[@"ios"];
        int version = [iosVer[@"vercode"] intValue];
        
        
        [[NSUserDefaults standardUserDefaults] setObject:sxdjs forKey:@"matterVCShowNumber"];
        
        if (MyVersionNum < version) {
            
            NSString *message = nil;
            if (qzgx.boolValue) {
                message = @"有重大升级，请务必更新";
            }else{
                message = @"是否更新新版本？";
            }
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"版本更新" message:message preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *cancelAC = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
            
            UIAlertAction *updateAC = [UIAlertAction actionWithTitle:@"更新版本" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://itunes.apple.com/gb/app/yi-dong-cai-bian/id1180288079?mt=8"]];
            }];

            //是否需要有”取消“按钮
            if (qzgx.boolValue) {
                [alert addAction:updateAC];
            }else{
                [alert addAction:cancelAC];
                [alert addAction:updateAC];
            }
            
            [self.window.rootViewController presentViewController:alert animated:YES completion:nil];

        }
        
    } failure:^(NSError *error) {
        
    }];

}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
