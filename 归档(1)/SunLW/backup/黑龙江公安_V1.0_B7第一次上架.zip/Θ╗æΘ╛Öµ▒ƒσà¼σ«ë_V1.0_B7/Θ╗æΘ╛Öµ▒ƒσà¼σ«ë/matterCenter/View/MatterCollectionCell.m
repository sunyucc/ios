//
//  MatterCollectionCell.m
//  黑龙江公安
//
//  Created by administrator on 16/11/23.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "MatterCollectionCell.h"

@implementation MatterCollectionCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        CGFloat cellW = self.contentView.frame.size.width;
        CGFloat cellH = self.contentView.frame.size.height;
        
        
        self.selectBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, 7.5, 20, 20)];
        [self.selectBtn setImage:[UIImage imageNamed:@"category_normal"] forState:UIControlStateNormal];
        [self.selectBtn setImage:[UIImage imageNamed:@"category_select"] forState:UIControlStateSelected];
        [self.contentView addSubview:self.selectBtn];

        
        self.titleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, cellW, cellH)];
        self.titleLab.textAlignment = NSTextAlignmentCenter;
        self.titleLab.textColor = [UIColor blackColor];
        [self.contentView addSubview:self.titleLab];

        
        UIView *topLine = [[UIView alloc] initWithFrame:CGRectMake(-1, 0, cellW+5, 1)];
        topLine.backgroundColor = [UIColor grayColor];
        UIView *bottomLine = [[UIView alloc] initWithFrame:CGRectMake(-1, cellH, cellW+5, 1)];
        bottomLine.backgroundColor = [UIColor grayColor];
        [self.contentView addSubview:topLine];
        [self.contentView addSubview:bottomLine];
        
        
    }
    
    return self;
    
}
@end
