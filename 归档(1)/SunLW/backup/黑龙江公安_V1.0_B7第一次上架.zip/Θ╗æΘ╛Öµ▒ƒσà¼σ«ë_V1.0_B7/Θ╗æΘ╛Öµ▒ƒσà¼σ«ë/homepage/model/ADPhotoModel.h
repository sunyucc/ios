//
//  ADPhotoModel.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ADPhotoModel : NSObject

@property (nonatomic) NSString *xwid;
@property (nonatomic) NSString *tplj;
@property (nonatomic) NSString *xwdz;
@property (nonatomic) NSString *sfgd;
@property (nonatomic) NSString *scbj;
@property (nonatomic) NSString *cjsj;
@property (nonatomic) NSString *gxsj;
@property (nonatomic) NSString *xwmc;


//        "data": [
//                 {
//                     "xwid": 1001,
//                     "tplj": "http://img.ads.csdn.net/2016/201610200947374106.jpg",
//                     "xwdz": "www.baidu.com",
//                     "sfgd": "y",
//                     "scbj": "n",
//                     "cjsj": "2016-11-16",
//                     "gxsj": "",
//                     "xwmc": "百度"


@end
