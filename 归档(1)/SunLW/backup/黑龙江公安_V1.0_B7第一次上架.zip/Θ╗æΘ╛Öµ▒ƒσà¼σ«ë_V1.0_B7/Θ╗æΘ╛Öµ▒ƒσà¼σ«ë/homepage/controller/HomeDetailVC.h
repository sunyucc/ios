//
//  HomeDetailVC.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ADPhotoModel.h"
#import "ModuleModel.h"
#import "MatterCenterModel.h"

@interface HomeDetailVC : UIViewController

@property (nonatomic, assign) int isADVC; //1－广告页 2-主页cell 3-事项中心cell

@property (nonatomic, copy) NSString *detailStr; //事项中心详情页面对应的H5页面的部分URL

@property (nonatomic, strong) ADPhotoModel *adModel;
@property (nonatomic, strong) ModuleModel *moduleModel;
@property (nonatomic, strong) MatterCenterModel *matterModel;

@end
