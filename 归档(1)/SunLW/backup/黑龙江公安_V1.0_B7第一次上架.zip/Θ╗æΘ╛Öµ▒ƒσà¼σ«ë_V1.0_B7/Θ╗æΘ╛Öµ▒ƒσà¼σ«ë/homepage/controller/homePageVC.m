//
//  homePageVC.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "homePageVC.h"
#import "HomeDetailVC.h" //详情页面，加载webview

#import "LoopScollView.h"

#import "SecondContrller.h" //第2个页面
#import "MatterCenterVC.h"//第3个页面
#import "PersonalCenterVC.h"//第4个页面

#import "ADPhotoModel.h"
#import "ModuleModel.h"

#import "HomeCell.h"
#import "HeaderView.h"
#import "UIButton+WebCache.h"
#import "MJRefresh.h"

#import "GetGrayPicture.h" //处理图片，返回灰色不选中状态图片

@interface homePageVC () <UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource, UIScrollViewDelegate, LoopScollViewDelegate>

{
    UICollectionView *_collectionView;
    NSMutableArray *_adPhotosArr; //轮播图
    
    NSMutableDictionary *_allTitleDic; //所有模块类别名称
    NSMutableArray *_allModuleArr; //所有模块总的数组
    
    UIView *_firstView; //
    UILabel *_firstLab;
    
    AFHTTPSessionManager *_manager;
    
    UIAlertController *_alertView;
    
}

@property (nonatomic,strong)NSMutableArray *imgPathArr;
@property (nonatomic,strong)LoopScollView *loopScrollView;

@end

@implementation homePageVC

//自定义返回按钮，回复右划返回手势
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor grayColor];
    
    
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
    [SVProgressHUD show];
    
    _adPhotosArr = [[NSMutableArray alloc] init];
    _imgPathArr = [[NSMutableArray alloc] init];
    
    _allTitleDic = [[NSMutableDictionary alloc] init];
    _allModuleArr = [[NSMutableArray alloc] init];
    
    [self setupHeaderView]; //设置广告图的位置
    
    _manager = [AFHTTPSessionManager manager];
    
    [self getAdPhotoData];
    [self setupModuleData];
    
    //创建一个layout布局类
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc]init];
    layout.minimumLineSpacing = 0; //行间距
    layout.minimumInteritemSpacing = 0;//列间距
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    layout.headerReferenceSize = CGSizeMake(0, sHeight / 5);
    
    //初始化collectionView
    _collectionView = [[UICollectionView alloc]initWithFrame:self.view.frame collectionViewLayout:layout];
    _collectionView.backgroundColor = [UIColor whiteColor];
    _collectionView.delegate=self;
    _collectionView.dataSource=self;
    [self.view addSubview:_collectionView];
    
    _collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
    [self setupModuleData];
        
    }];
    
    //cell
    [_collectionView registerClass:[HomeCell class] forCellWithReuseIdentifier:@"cellid"];

    //注册头视图
    [_collectionView registerClass:[HeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"UICollectionViewHeader"];
    
    self.navigationItem.backBarButtonItem = nil;
    
    
    _alertView = [UIAlertController alertControllerWithTitle:@"提示" message:@"请检查网络" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *refreshAct = [UIAlertAction actionWithTitle:@"尝试刷新" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
       
        [SVProgressHUD show];
        [self setupModuleData];
        
    }];
    
    [_alertView addAction:refreshAct];
}

#pragma mark --//获取轮播图数据
- (void)getAdPhotoData
{
    NSDictionary *parameters = @{@"pageIndex":@"1",@"pageSize":@"3"};
    //广告图片请求61.180.150.46
    
    
    [_manager GET:HomePage_Get_AdPhotoData parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        [_adPhotosArr removeAllObjects];
        [_imgPathArr removeAllObjects];
        
        NSArray *resultArr = responseObject[@"data"];
        for (NSDictionary *dict in resultArr) {
            ADPhotoModel *adModel = [[ADPhotoModel alloc] init];
            [adModel setValuesForKeysWithDictionary:dict];
            [_adPhotosArr addObject:adModel];
            [_imgPathArr addObject:dict[@"tplj"]];
        }
        
        [self.loopScrollView setPictureArray:self.imgPathArr];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        [_adPhotosArr removeAllObjects];
        [_imgPathArr removeAllObjects];
        
        for (int i = 0; i < 3; i++) {
            
            ADPhotoModel *adModel = [[ADPhotoModel alloc] init];
            [_adPhotosArr addObject:adModel];
            [_imgPathArr addObject:@""];
        }
        
        [self.loopScrollView setPictureArray:self.imgPathArr];
        
        
    }];

}
#pragma mark --//获取模块数据
- (void)setupModuleData
{
    //模块数据请求
    [_manager GET:HomePage_Get_ModuleData parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        [_allModuleArr removeAllObjects];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
        });
        
        //init各个数组
        NSArray *allArr = [NSArray arrayWithArray:responseObject];
        for (int i = 0; i < allArr.count-3; i++) {
            NSMutableArray *moduleArr = [[NSMutableArray alloc] init];
            [_allModuleArr addObject:moduleArr];
        }
        
        for (NSDictionary *dict in responseObject) {
            
            //存储模块名称和key
            NSString *indexStr = [NSString stringWithFormat:@"%@", dict[@"mklb"]];
            [_allTitleDic setObject:dict[@"mc"] forKey:indexStr];
            
            for (NSDictionary *resultDic in dict[@"data"]) {
                
                ModuleModel *model = [[ModuleModel alloc] init];
                [model setValuesForKeysWithDictionary:resultDic];
                
                int index = model.mklb.intValue;
                if (index > 0 && index < 4) {
                    //其他三页tabbarItme数据
                    [self setOherTabbarIndex:index model:model page:index];
                }else{
                    //首页各个模块数据  index - 4
                    [_allModuleArr[index - 4] addObject:model];

                }
            }
        }
        
        [_collectionView reloadData];
        [_collectionView.mj_header endRefreshing];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
            [self presentViewController:_alertView animated:YES completion:nil];
        });
        
        //结束下拉刷新
        [_collectionView.mj_header endRefreshing];
        
    }];
    
}


//动态设置其他三个tabbar名称内容
- (void)setOherTabbarIndex:(int)index model:(ModuleModel *)model page:(int)page
{
    UINavigationController *sonNC = self.tabBarController.childViewControllers[index];
    NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:model.tbdz]];
    
    UIImage *normolImage = nil;

    if ((int)imageData.length == 0) {
        
        normolImage = [UIImage imageNamed:@"loading_default"];
    }else{
        normolImage = [UIImage imageWithData:imageData];
    }
    
        
    UIImage *grayImage = [GetGrayPicture grayscale:normolImage type:1];
    
    if (page == 1) {
        SecondContrller *secondVC = [sonNC.childViewControllers objectAtIndex:0];
        secondVC.navigationItem.title = model.mkmc;
        secondVC.urlStr = model.qqdz;
        [secondVC.itemBtn setTitle: model.mkmc forState:UIControlStateNormal];
        [secondVC.itemBtn setImage:grayImage forState:UIControlStateNormal];
        [secondVC.itemBtn setImage:normolImage forState:UIControlStateSelected];
    }
    
    if (page == 2) {        
        MatterCenterVC *matterVC = [sonNC.childViewControllers objectAtIndex:0];
        [matterVC.itemBtn setTitle: model.mkmc forState:UIControlStateNormal];
        [matterVC.itemBtn setImage:grayImage forState:UIControlStateNormal];
        [matterVC.itemBtn setImage:normolImage forState:UIControlStateSelected];
        matterVC.navigationItem.title = model.mkmc;
        matterVC.detailStr = model.qqdz;
    }
    
    if (page == 3) {
        PersonalCenterVC *secondVC = [sonNC.childViewControllers objectAtIndex:0];
        [secondVC.itemBtn setTitle: model.mkmc forState:UIControlStateNormal];
        [secondVC.itemBtn setImage:grayImage forState:UIControlStateNormal];
        [secondVC.itemBtn setImage:normolImage forState:UIControlStateSelected];
        secondVC.navigationItem.title = model.mkmc;
        secondVC.urlStr = model.qqdz;
    }

}

#pragma mark -- collection deleagate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSMutableArray *sectionArr = _allModuleArr[section];
    return sectionArr.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    HomeCell * cell  = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellid" forIndexPath:indexPath];
    
    cell.leftLine.hidden = YES;
    cell.rightLine.hidden = YES;
    
    NSMutableArray *sectionArr = _allModuleArr[indexPath.section];

    ModuleModel *model = sectionArr[indexPath.row];
        
    if (indexPath.row % 1 == 0  || indexPath.row % 3 == 1) {
        cell.rightLine.hidden = NO;

    }
    
    [cell.iconView sd_setImageWithURL:[NSURL URLWithString:model.tbdz]
          placeholderImage:[UIImage imageNamed:@"loading_default"]];
    cell.titleLab.text = model.mkmc;
    
    return cell;

}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGSize size = CGSizeMake(sWidth/3,sWidth/3*0.8);
    return size;
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

//////////第一个头view
- (void)setupHeaderView
{
    _firstView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, sWidth, sHeight/5+40)];
    [_firstView addSubview:self.loopScrollView];
    
    _firstLab = [[UILabel alloc] initWithFrame:CGRectMake(10,  _firstView.frame.size.height-40, sWidth-10, 40)];
    _firstLab.backgroundColor = [UIColor whiteColor];
    [_firstView addSubview:_firstLab];

}

#pragma mark -- 设置section头视图的参考大小，与tableheaderview类似
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout
referenceSizeForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return CGSizeMake(sWidth, sHeight/5+40);
    }
    else {
        return CGSizeMake(sWidth, 40);
    }
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *headView = nil;
    
    headView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"UICollectionViewHeader" forIndexPath:indexPath];
    
    for (UIView *subView in headView.subviews) {
        [subView removeFromSuperview];
    }
    
    if (indexPath.section == 0) {
        _firstLab.text = _allTitleDic[@"04"];
        [headView addSubview:_firstView];

    }else{
        
        UILabel *nameLab = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, sWidth-10, 40)];
        NSString *indexStr = [NSString stringWithFormat:@"0%d", (int)indexPath.section+4];
        nameLab.text = _allTitleDic[indexStr];
        [headView addSubview:nameLab];
    }
    
    return headView;

}

#pragma mark -- collection didselect
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray *sectionArr = _allModuleArr[indexPath.section];
    
    ModuleModel *model = sectionArr[indexPath.row];
    
    HomeDetailVC *detailVC = [[HomeDetailVC alloc] init];
    detailVC.isADVC = 2;
    detailVC.title = model.mkmc;
    detailVC.moduleModel = model;
    [self setHidesBottomBarWhenPushed:YES];
    
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)])
        {
            self.navigationController.interactivePopGestureRecognizer.enabled = YES;
            self.navigationController.interactivePopGestureRecognizer.delegate = nil;
        }
    
    [self.navigationController pushViewController:detailVC animated:YES];
    [self setHidesBottomBarWhenPushed:NO];
}

//广告图轮播的点击事件
#pragma mark -- loopScrollView delegate

- (void)tapScrollPicture:(int)pictureTag
{
    
    if (_adPhotosArr.count == 0) {
        
        return;
    }
    
    ADPhotoModel *model = _adPhotosArr[pictureTag];
    
    HomeDetailVC *detailVC = [[HomeDetailVC alloc] init];
    detailVC.title = model.xwmc;
    detailVC.isADVC = 1;
    detailVC.adModel = model;
    [self setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:detailVC animated:YES];
    
    [self setHidesBottomBarWhenPushed:NO];

}

- (LoopScollView *)loopScrollView
{
    if (_loopScrollView == nil) {
        _loopScrollView = [[LoopScollView alloc] initWithFrame:CGRectMake(0, 0, sWidth, sHeight/5)];
        _loopScrollView.delegate = self;
    }
    return _loopScrollView;
}

#pragma mark -- collectionView delegate

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return _allModuleArr.count;
}

@end
