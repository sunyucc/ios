//
//  SecondContrller.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/18.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "BaseFatherVC.h"

@interface SecondContrller : BaseFatherVC

@end
