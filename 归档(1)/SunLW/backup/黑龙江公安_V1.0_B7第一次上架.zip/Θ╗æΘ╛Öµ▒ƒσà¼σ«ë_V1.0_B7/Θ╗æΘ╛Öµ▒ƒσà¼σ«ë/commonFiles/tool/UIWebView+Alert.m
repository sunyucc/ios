//
//  UIWebView+Alert.m
//  黑龙江公安
//
//  Created by administrator on 16/11/27.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "UIWebView+Alert.h"

@implementation UIWebView (Alert)

- (void)webView:(UIWebView *)sender runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(id)frame;
{
    
    UIAlertView* customAlert = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil];
    
    [customAlert show];
}


@end
