//
//  UIWebView+Alert.h
//  黑龙江公安
//
//  Created by administrator on 16/11/27.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWebView (Alert)

- (void)webView:(UIWebView *)sender runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(id)frame;

@end
