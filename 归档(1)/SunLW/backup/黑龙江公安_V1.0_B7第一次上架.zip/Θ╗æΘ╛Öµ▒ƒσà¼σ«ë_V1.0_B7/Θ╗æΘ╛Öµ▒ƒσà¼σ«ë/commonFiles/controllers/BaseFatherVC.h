//
//  BaseFatherVC.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/18.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTabbarBtn.h"

@interface BaseFatherVC : UIViewController

@property (nonatomic, copy) NSString *urlStr;
@property (nonatomic, strong) MyTabbarBtn *itemBtn;

@property (nonatomic, strong) UIProgressView *progressView;
@property (nonatomic, assign) NSUInteger loadCount;

@end
