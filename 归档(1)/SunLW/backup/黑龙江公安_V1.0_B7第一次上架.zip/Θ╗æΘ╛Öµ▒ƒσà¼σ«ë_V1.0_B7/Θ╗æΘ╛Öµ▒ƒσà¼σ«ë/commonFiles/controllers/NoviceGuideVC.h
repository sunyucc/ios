//
//  NoviceGuideVC.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/16.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoviceGuideVC : UIViewController

@property (nonatomic, assign) BOOL isNewVersion;

@end
