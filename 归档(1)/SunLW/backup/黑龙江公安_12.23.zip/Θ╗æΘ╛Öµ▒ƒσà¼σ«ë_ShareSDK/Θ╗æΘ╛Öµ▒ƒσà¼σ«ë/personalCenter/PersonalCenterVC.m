//
//  PersonalCenterVC.m
//  黑龙江公安
//
//  Created by administrator on 16/11/25.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "PersonalCenterVC.h"
#import "MJRefresh.h"

#import "NJKWebViewProgressView.h"
#import "NJKWebViewProgress.h"

@interface PersonalCenterVC () <UIWebViewDelegate, NJKWebViewProgressDelegate>

{
    UIBarButtonItem *_backBarBtn;
    UIBarButtonItem *_closeBarBtn;
    
    NSMutableArray *_historyListArr;
    
    NSString *_currentURLStr;
    
    NJKWebViewProgressView *_webViewProgressView;
    NJKWebViewProgress *_webViewProgress;
}

@property (nonatomic, strong) UIView *warmingView;
@property (nonatomic, strong) UIButton *refreshBtn;

@property (nonatomic, strong) UIWebView *webView;


@end

@implementation PersonalCenterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.automaticallyAdjustsScrollViewInsets = NO;

    _historyListArr = [[NSMutableArray alloc] init];
    
    _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 64, sWidth, sHeight-64-49)];
    _webView.delegate = self;
    [self.view addSubview:_webView];
    [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.urlStr]]];
    
    _webView.scrollView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        //如果是登录页面，刷新动时候直接重新加载个人中心页面
        if ([_currentURLStr containsString:@"login.html"]) {
            [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.urlStr]]];
        }else{
            [_webView reload];
        }
        
    }];
    
    [self setupBackBtn];
    [self setupProgressView];
}


- (void)setupBackBtn
{
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    backBtn.frame = CGRectMake(10, 20, 50, 40);
    [backBtn setTitle:@"返回" forState:UIControlStateNormal];
    backBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    [backBtn addTarget:self action:@selector(backBtnClick) forControlEvents:UIControlEventTouchUpInside];
    _backBarBtn = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    
    // 让按钮内部的所有内容左对齐
    backBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    // 让按钮的内容往左边偏移10
    backBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -20, 0, 0);
    [backBtn setImage:[UIImage imageNamed:@"nav_back"] forState:UIControlStateNormal];
    
    
    UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    closeBtn.frame = CGRectMake(10, 20, 40, 40);
    closeBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    [closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
    [closeBtn addTarget:self action:@selector(closeBtnClick) forControlEvents:UIControlEventTouchUpInside];
    
    _closeBarBtn = [[UIBarButtonItem alloc] initWithCustomView:closeBtn];
    
}

//返回按钮
- (void)backBtnClick
{
    self.warmingView.hidden = YES;
    
    if ([_webView canGoBack]) {
        [_webView goBack];
        [_historyListArr removeObject:_currentURLStr];
    }
    
    int count = (int)_historyListArr.count;
    
    if (count > 2) {
        
        self.navigationItem.leftBarButtonItems = @[_backBarBtn, _closeBarBtn];
        
    }else if (count == 2){
        
        self.navigationItem.leftBarButtonItems = @[_backBarBtn];
        
    }else if (count == 1){
        self.navigationItem.leftBarButtonItems = nil;
        
    }
}

//关闭按钮
- (void)closeBtnClick
{
    
    self.warmingView.hidden = YES;
    int count = (int)_historyListArr.count;
    
    while (count > 1) {
        [_webView goBack];
        [_historyListArr removeObject:_currentURLStr];
        count --;
    }
    
    self.navigationItem.leftBarButtonItem = nil;
    
}

//页面加载完成之后调用
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [_webView.scrollView.mj_header endRefreshing];
    
    _currentURLStr = [NSString stringWithFormat:@"%@", webView.request.URL];
    
    if ([_currentURLStr containsString:@"login.html"] || [_currentURLStr containsString:self.urlStr]) {
        [_webView stringByEvaluatingJavaScriptFromString:@"typemeg(4)"];
        [_historyListArr removeAllObjects];
    }
    
    if (![_historyListArr containsObject:_currentURLStr]) {
        [_historyListArr addObject:_currentURLStr];
    }
    
    int  count = (int)_historyListArr.count;
    if (count == 1) {
        self.navigationItem.leftBarButtonItem = nil;
    }
    if (count == 2) {
        self.navigationItem.leftBarButtonItem = _backBarBtn;
    }
    if (count > 2) {
        self.navigationItem.leftBarButtonItems = @[_backBarBtn, _closeBarBtn];
    }

}

//webview加载失败
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [_webView.scrollView.mj_header endRefreshing];
    
    if([error code] == NSURLErrorCancelled)
    {
        return;
    }
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
    [SVProgressHUD showErrorWithStatus:@"加载失败"];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
    });

}

//网络不好，刷新view
- (UIView *)warmingView
{
    if (_warmingView == nil) {
        
        _warmingView = [[UIView alloc] initWithFrame:CGRectMake(0, 64, sWidth, sHeight-113)];
        _warmingView.backgroundColor = [UIColor whiteColor];
        _warmingView.hidden = YES;
        [_warmingView addSubview:self.refreshBtn];
        [self.view addSubview:_warmingView];
        UIImageView *wifiIcon = [[UIImageView alloc] initWithFrame:CGRectMake((sWidth-100)/2, sHeight/2-100, 100, 100)];
        wifiIcon.image = [UIImage imageNamed:@"wifi_no"];
        [_warmingView addSubview:wifiIcon];
        
    }
    
    return _warmingView;
}

- (UIButton *)refreshBtn
{
    if (_refreshBtn == nil) {
        _refreshBtn = [[UIButton alloc] initWithFrame:CGRectMake((sWidth-100)/2, sHeight/2, 100, 30)];
        [_refreshBtn addTarget:self action:@selector(setupRefreshView) forControlEvents:UIControlEventTouchUpInside];
        [_refreshBtn setTitle:@"重新加载" forState:UIControlStateNormal];
        _refreshBtn.layer.borderWidth = 1;
        _refreshBtn.layer.masksToBounds = YES;
        _refreshBtn.layer.cornerRadius = 4;
        [_refreshBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    }
    
    return _refreshBtn;
}

- (void)setupRefreshView
{
    _warmingView.hidden = YES;
    [_webView reload];
}

//进度条
- (void)setupProgressView
{
    _webViewProgress = [[NJKWebViewProgress alloc] init];
    _webView.delegate = _webViewProgress;
    _webViewProgress.webViewProxyDelegate = self;
    _webViewProgress.progressDelegate = self;
    CGRect navBounds = self.navigationController.navigationBar.bounds;
    CGRect barFrame = CGRectMake(0,
                                 navBounds.size.height - 2,
                                 navBounds.size.width,
                                 2);
    _webViewProgressView = [[NJKWebViewProgressView alloc] initWithFrame:barFrame];
    _webViewProgressView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    [_webViewProgressView setProgress:0 animated:YES];
    [self.navigationController.navigationBar addSubview:_webViewProgressView];
    
}
#pragma mark - NJKWebViewProgressDelegate
-(void)webViewProgress:(NJKWebViewProgress *)webViewProgress updateProgress:(float)progress
{
    [_webViewProgressView setProgress:progress animated:YES];
//    self.title = [_webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    self.navigationItem.title = [_webView stringByEvaluatingJavaScriptFromString:@"document.title"];
}


@end
