//
//  HLJTabbarcontroller.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>
/*
 tabbarController，把app页面分为4个部分。
 */

@interface HLJTabbarcontroller : UITabBarController

@end
