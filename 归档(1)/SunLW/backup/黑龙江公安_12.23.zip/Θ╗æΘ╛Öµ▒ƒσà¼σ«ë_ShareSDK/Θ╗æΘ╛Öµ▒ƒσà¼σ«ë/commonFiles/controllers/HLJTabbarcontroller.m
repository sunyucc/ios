//
//  HLJTabbarcontroller.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "HLJTabbarcontroller.h"

#import "HLJNavigationController.h"
#import "homePageVC.h"

#import "SecondContrller.h" //第2个页面
#import "MatterCenterVC.h"//第3个页面

#import "PersonalCenterVC.h"//第4个页面

#import "GetGrayPicture.h" //处理图片，返回灰色不选中状态图片

@interface HLJTabbarcontroller ()

{
    MyTabbarBtn *_tempBtn;
    UIColor *_selectColor;
}

@end

@implementation HLJTabbarcontroller

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIView *myTabbar = [[UIView alloc] initWithFrame:self.tabBar.bounds];
    
    for (int i = 0 ; i < 4; i++) {
        
        MyTabbarBtn *btn = [[MyTabbarBtn alloc] initWithFrame:CGRectMake(sWidth/4*i, 0, sWidth/4, self.tabBar.frame.size.height)];
        [btn addTarget:self action:@selector(itemBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = 777 + i;
        
        [btn setTitle:@"加载中" forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"loading_default"] forState:UIControlStateNormal];
        
        if (!i) {
            _tempBtn = btn;
            _tempBtn.selected = YES;
            [_tempBtn setImage:[UIImage imageNamed:@"loading_select"] forState:UIControlStateNormal];
        }
        
        [myTabbar addSubview:btn];
    }

    
    [self.tabBar addSubview:myTabbar];
    
//第1个页面
    homePageVC *firstVC = [[homePageVC alloc] init];
    firstVC.title = @"首页";
    firstVC.itemBtn = (MyTabbarBtn *)[self.tabBar viewWithTag:777];
    [firstVC.itemBtn setTitle:@"首页" forState:UIControlStateNormal];
    
    UIImage *homePage_select = [UIImage imageNamed:@"homePage_select"];
    UIImage *homePage_normol = [GetGrayPicture grayscale:homePage_select type:1];
    
    [firstVC.itemBtn setImage:homePage_normol forState:UIControlStateNormal];
    [firstVC.itemBtn setImage:homePage_select forState:UIControlStateSelected];
    HLJNavigationController *firstNC = [[HLJNavigationController alloc] initWithRootViewController:firstVC];
    [self addChildViewController:firstNC];
    
//第2个页面
    SecondContrller *secondVC = [[SecondContrller alloc] init];
    secondVC.itemBtn = (MyTabbarBtn *)[self.tabBar viewWithTag:778];
    HLJNavigationController *secondNC = [[HLJNavigationController alloc] initWithRootViewController:secondVC];
    [self addChildViewController:secondNC];
    
//第3个页面
//    ThirdController *thirdVC = [[ThirdController alloc] init];
//    thirdVC.itemBtn = (MyTabbarBtn *)[self.tabBar viewWithTag:779];
//    HLJNavigationController *thirdNC = [[HLJNavigationController alloc] initWithRootViewController:thirdVC];
//    [self addChildViewController:thirdNC];
//    
//    
    
    MatterCenterVC *matterVC = [[MatterCenterVC alloc] init];
    matterVC.itemBtn = (MyTabbarBtn *)[self.tabBar viewWithTag:779];
    HLJNavigationController *thirdNC = [[HLJNavigationController alloc] initWithRootViewController:matterVC];
    [self addChildViewController:thirdNC];

//第4个页面
    PersonalCenterVC *fouthVC = [[PersonalCenterVC alloc] init];
    fouthVC.itemBtn = (MyTabbarBtn *)[self.tabBar viewWithTag:780];
    HLJNavigationController *fouthNC = [[HLJNavigationController alloc] initWithRootViewController:fouthVC];
    [self addChildViewController:fouthNC];

}

- (void)itemBtnClick:(MyTabbarBtn *)sender
{
    int page = (int)sender.tag - 777;
    _tempBtn.selected = NO;
    _tempBtn = sender;
    sender.selected = YES;
    self.selectedIndex = page;
}

//移除系统自带item
- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    
    for (UIView *child in self.tabBar.subviews) {
        
        if ([child isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            
            [child removeFromSuperview];
        }
    }
}

@end
