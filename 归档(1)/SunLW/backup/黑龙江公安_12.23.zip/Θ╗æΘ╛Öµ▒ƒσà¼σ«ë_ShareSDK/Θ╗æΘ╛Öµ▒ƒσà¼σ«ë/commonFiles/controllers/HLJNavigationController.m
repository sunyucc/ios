//
//  HLJNavigationController.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "HLJNavigationController.h"

@interface HLJNavigationController ()

@end

@implementation HLJNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    self.interactivePopGestureRecognizer.enabled = NO;

}

//- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
//{
//
//    [super pushViewController:viewController animated:animated];
//    
//    if (self.childViewControllers.count) { // 不是根控制器
//        id target = self.navigationController.interactivePopGestureRecognizer.delegate;
//        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:target action:@selector(handleNavigationTransition:)];
//        pan.delegate = viewController;
//    }
//    
//}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
