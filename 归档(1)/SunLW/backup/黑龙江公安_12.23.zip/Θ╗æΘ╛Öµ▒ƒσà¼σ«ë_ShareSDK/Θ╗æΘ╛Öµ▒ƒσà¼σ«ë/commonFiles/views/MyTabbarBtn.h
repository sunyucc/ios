//
//  MyTabbarBtn.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/18.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTabbarBtn : UIButton
/*
 自定义tabbar按钮，没有使用系统自带的按钮。
 */

@end
