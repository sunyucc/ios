//
//  homePageVC.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "homePageVC.h"
#import "HomeDetailVC.h" //详情页面，加载webview

#import "LoopScollView.h"

#import "SecondContrller.h" //第2个页面
#import "MatterCenterVC.h"//第3个页面
#import "PersonalCenterVC.h"//第4个页面

#import "ADPhotoModel.h"
#import "ModuleModel.h"

#import "HomeCell.h"
#import "HeaderView.h"
#import "UIButton+WebCache.h"
#import "MJRefresh.h"

#import "NormolBtn.h"
#import <ShareSDK/ShareSDK.h>
#import <ShareSDKUI/ShareSDK+SSUI.h>
#import "WeiboSDK.h"


#import "GetGrayPicture.h" //处理图片，返回灰色不选中状态图片

@interface homePageVC () <UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource, UIScrollViewDelegate, LoopScollViewDelegate>

{
    UICollectionView *_collectionView;
    NSMutableArray *_adPhotosArr; //轮播图
    
    NSMutableDictionary *_allTitleDic; //所有模块类别名称
    NSMutableArray *_allModuleArr; //所有模块总的数组
    
    UIView *_firstView; //
    UILabel *_firstLab;
    
    UIAlertController *_alertView;
    
    NSString *_newUrlStr;
    
}

@property (nonatomic,strong)NSMutableArray *imgPathArr;
@property (nonatomic,strong)LoopScollView *loopScrollView;

@end

@implementation homePageVC

//自定义返回按钮，恢复右划返回手势
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor grayColor];
    
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
    [SVProgressHUD show];
    
    _adPhotosArr = [[NSMutableArray alloc] init];
    _imgPathArr = [[NSMutableArray alloc] init];
    
    _allTitleDic = [[NSMutableDictionary alloc] init];
    _allModuleArr = [[NSMutableArray alloc] init];
    
    [self setupHeaderView]; //设置广告图的位置
        
    [self getAdPhotoData];
    [self setupModuleData];
    
    //创建一个layout布局类
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc]init];
    layout.minimumLineSpacing = 0; //行间距
    layout.minimumInteritemSpacing = 0;//列间距
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    layout.headerReferenceSize = CGSizeMake(0, sHeight / 5);
    
    //初始化collectionView
    _collectionView = [[UICollectionView alloc]initWithFrame:self.view.frame collectionViewLayout:layout];
    _collectionView.backgroundColor = [UIColor whiteColor];
    _collectionView.delegate=self;
    _collectionView.dataSource=self;
    [self.view addSubview:_collectionView];
    
    _collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
    [self setupModuleData];
        
    }];
    
    [_collectionView registerClass:[HomeCell class] forCellWithReuseIdentifier:@"cellid"];

    //注册头视图
    [_collectionView registerClass:[HeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"UICollectionViewHeader"];
    
    self.navigationItem.backBarButtonItem = nil;
    
    
    _alertView = [UIAlertController alertControllerWithTitle:@"提示" message:@"请检查网络" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *refreshAct = [UIAlertAction actionWithTitle:@"尝试刷新" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
       
        [SVProgressHUD show];
        [self setupModuleData];
        
    }];
    
    [_alertView addAction:refreshAct];
}

#pragma mark --//获取轮播图数据
- (void)getAdPhotoData
{
//    NSDictionary *parameters = @{@"pageIndex":@"1",@"pageSize":@"3"};
    NSDictionary *parameters = @{@"pageIndex":@"1"};
    
    [MyAFNet getData:HomePage_Get_AdPhotoData parameters:parameters success:^(id responseObject) {
        [_adPhotosArr removeAllObjects];
        [_imgPathArr removeAllObjects];
        
        NSArray *resultArr = responseObject[@"data"];
        
        for (NSDictionary *dict in resultArr) {
            
            ADPhotoModel *adModel = [[ADPhotoModel alloc] init];
            [adModel setValuesForKeysWithDictionary:dict];
            [_adPhotosArr addObject:adModel];
            [_imgPathArr addObject:dict[@"tplj"]];
        }
        
        [self.loopScrollView setPictureArray:self.imgPathArr];

        
    } failure:^(NSError *error) {
        [_adPhotosArr removeAllObjects];
        [_imgPathArr removeAllObjects];
        
        for (int i = 0; i < 3; i++) {
            
            ADPhotoModel *adModel = [[ADPhotoModel alloc] init];
            [_adPhotosArr addObject:adModel];
            [_imgPathArr addObject:@""];
        }
        
        [self.loopScrollView setPictureArray:_imgPathArr];
        
    }];

}
#pragma mark --//获取模块数据
- (void)setupModuleData
{
    //模块数据请求
    [MyAFNet getData:HomePage_Get_ModuleData parameters:nil success:^(id responseObject) {
        [_allModuleArr removeAllObjects];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
        
        //init各个数组
        NSArray *allArr = [NSArray arrayWithArray:responseObject];
        for (int i = 0; i < allArr.count-3; i++) {
            NSMutableArray *moduleArr = [[NSMutableArray alloc] init];
            [_allModuleArr addObject:moduleArr];
        }
        
        for (NSDictionary *dict in responseObject) {
            
            //存储模块名称和key
            NSString *indexStr = [NSString stringWithFormat:@"%@", dict[@"mklb"]];
            [_allTitleDic setObject:dict[@"mc"] forKey:indexStr];
            
            for (NSDictionary *resultDic in dict[@"data"]) {
                
                ModuleModel *model = [[ModuleModel alloc] init];
                [model setValuesForKeysWithDictionary:resultDic];
                
                if ([model.mkmc isEqualToString:@"警方新闻"]) {
                    _newUrlStr = model.qqdz;
                }
                
                int index = model.mklb.intValue;
                if (index > 0 && index < 4) {
                    //其他三页tabbarItme数据
                    [self setOherTabbarIndex:index model:model page:index];
                }else{
                    //首页各个模块数据  index - 4
                    [_allModuleArr[index - 4] addObject:model];
                }
            }
        }
        
        [_collectionView reloadData];
        [_collectionView.mj_header endRefreshing];

    } failure:^(NSError *error) {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
            [self presentViewController:_alertView animated:YES completion:nil];
        });
        
        //结束下拉刷新
        [_collectionView.mj_header endRefreshing];

    }];
    
}

//动态设置其他三个tabbar名称内容
- (void)setOherTabbarIndex:(int)index model:(ModuleModel *)model page:(int)page
{
    UINavigationController *sonNC = self.tabBarController.childViewControllers[index];
    NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:model.tbdz]];
    
    UIImage *normolImage = nil;

    if ((int)imageData.length == 0) {
        
        normolImage = [UIImage imageNamed:@"loading_default"];
    }else{
        normolImage = [UIImage imageWithData:imageData];
    }
    
    UIImage *grayImage = [GetGrayPicture grayscale:normolImage type:1];
    
    if (page == 1) {
        SecondContrller *secondVC = [sonNC.childViewControllers objectAtIndex:0];
        secondVC.navigationItem.title = model.mkmc;
        secondVC.urlStr = model.qqdz;
        [secondVC.itemBtn setTitle: model.mkmc forState:UIControlStateNormal];
        [secondVC.itemBtn setImage:grayImage forState:UIControlStateNormal];
        [secondVC.itemBtn setImage:normolImage forState:UIControlStateSelected];
    }
    
    if (page == 2) {
        
        MatterCenterVC *matterVC = [sonNC.childViewControllers objectAtIndex:0];
        [matterVC.itemBtn setTitle: model.mkmc forState:UIControlStateNormal];
        matterVC.navigationItem.title = model.mkmc;
        [matterVC.itemBtn setImage:grayImage forState:UIControlStateNormal];
        [matterVC.itemBtn setImage:normolImage forState:UIControlStateSelected];
        matterVC.detailStr = model.qqdz;

    }
    
    if (page == 3) {
        PersonalCenterVC *secondVC = [sonNC.childViewControllers objectAtIndex:0];
        [secondVC.itemBtn setTitle: model.mkmc forState:UIControlStateNormal];
        [secondVC.itemBtn setImage:grayImage forState:UIControlStateNormal];
        [secondVC.itemBtn setImage:normolImage forState:UIControlStateSelected];
        secondVC.navigationItem.title = model.mkmc;
        secondVC.urlStr = model.qqdz;
    }

}

#pragma mark -- collection deleagate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSMutableArray *sectionArr = _allModuleArr[section];
    return sectionArr.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    HomeCell * cell  = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellid" forIndexPath:indexPath];
    
    cell.leftLine.hidden = YES;
    cell.rightLine.hidden = YES;
    
    NSMutableArray *sectionArr = _allModuleArr[indexPath.section];

    ModuleModel *model = sectionArr[indexPath.row];
        
    if (indexPath.row % 1 == 0  || indexPath.row % 3 == 1) {
        cell.rightLine.hidden = NO;

    }
    
    [cell.iconView sd_setImageWithURL:[NSURL URLWithString:model.tbdz]
          placeholderImage:[UIImage imageNamed:@"loading_default"]];
    cell.titleLab.text = model.mkmc;
    
    return cell;

}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGSize size = CGSizeMake(sWidth/3,sWidth/3*0.8);
    return size;
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}
#pragma mark -- 第一个头view
- (void)setupHeaderView
{
    NSArray *nameArr = @[@"警务资讯", @"公安微博", @"用户分享"];
    NSArray *iconArr = @[@"ic_information", @"weibo_Icon", @"ic_share"];
    
    _firstView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, sWidth, sHeight/5+40 + 100)];
    [_firstView addSubview:self.loopScrollView];
    
    UIView *btnsView = [[UIView alloc] initWithFrame:CGRectMake(0, self.loopScrollView.frame.size.height, sWidth, sWidth/3)];
    [_firstView addSubview:btnsView];
    
    for (int i = 0; i < 3; i++) {
        NormolBtn *btn = [[NormolBtn alloc] initWithFrame:CGRectMake(i * sWidth/3, 0, sWidth/3, 100)];
        [btn setTitle:nameArr[i] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:iconArr[i]] forState:UIControlStateNormal];
        btn.tag = 333 + i;
        [btn addTarget:self action:@selector(threeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [btnsView addSubview:btn];
        
    }
    
    UILabel *lineLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 99, sWidth, 1)];
    lineLab.backgroundColor = [UIColor colorWithRed:220/255.f green:220/255.f blue:220/255.f alpha:1];
    
    [btnsView addSubview:lineLab];
    
    _firstLab = [[UILabel alloc] initWithFrame:CGRectMake(0,  _firstView.frame.size.height-40, sWidth, 40)];
    _firstLab.backgroundColor =  [UIColor colorWithRed:245/255.f green:245/255.f blue:245/255.f alpha:1];

    [_firstView addSubview:_firstLab];

}

#pragma mark -- 设置section头视图的参考大小，与tableheaderview类似
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout
referenceSizeForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return CGSizeMake(sWidth, sHeight/5+40+100);
    }
    else {
        return CGSizeMake(sWidth, 40);
    }
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *headView = nil;
    
    headView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"UICollectionViewHeader" forIndexPath:indexPath];
        
    for (UIView *subView in headView.subviews) {
        [subView removeFromSuperview];
    }
    
    if (indexPath.section == 0) {
        _firstLab.text = [NSString stringWithFormat:@"  %@", _allTitleDic[@"04"]];
        [headView addSubview:_firstView];

    }else{
        
        UILabel *nameLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 1, sWidth, 39)];
        nameLab.backgroundColor =  [UIColor colorWithRed:245/255.f green:245/255.f blue:245/255.f alpha:1];

        NSString *indexStr = [NSString stringWithFormat:@"0%d", (int)indexPath.section+4];
        nameLab.text = [NSString stringWithFormat:@"  %@", _allTitleDic[indexStr]];
        [headView addSubview:nameLab];
    }
    
    return headView;

}

#pragma mark -- collection didselect
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray *sectionArr = _allModuleArr[indexPath.section];
    
    ModuleModel *model = sectionArr[indexPath.row];
    
    HomeDetailVC *detailVC = [[HomeDetailVC alloc] init];
    detailVC.isADVC = 2;
    detailVC.title = model.mkmc;
    detailVC.moduleModel = model;
    [self setHidesBottomBarWhenPushed:YES];
    
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]){
            self.navigationController.interactivePopGestureRecognizer.enabled = YES;
            self.navigationController.interactivePopGestureRecognizer.delegate = nil;
    }
    
    [self.navigationController pushViewController:detailVC animated:YES];
    [self setHidesBottomBarWhenPushed:NO];
}

//广告图轮播的点击事件
#pragma mark -- loopScrollView delegate
- (void)tapScrollPicture:(int)pictureTag
{    
    ADPhotoModel *model = _adPhotosArr[pictureTag];
    
    if (model.xwdz.length == 0 || model.tplj.length == 0) {
        return;
    }
    
    HomeDetailVC *detailVC = [[HomeDetailVC alloc] init];
    detailVC.title = model.xwmc;
    detailVC.isADVC = 1;
    detailVC.adModel = model;
    [self setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:detailVC animated:YES];
    
    [self setHidesBottomBarWhenPushed:NO];

}

- (LoopScollView *)loopScrollView
{
    if (_loopScrollView == nil) {
        _loopScrollView = [[LoopScollView alloc] initWithFrame:CGRectMake(0, 0, sWidth, sHeight/5)];
        _loopScrollView.delegate = self;
    }
    return _loopScrollView;
}

#pragma mark -- collectionView delegate

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return _allModuleArr.count;
}

#pragma mark -- 三个按钮的点击事件
- (void)threeBtnClick:(NormolBtn *)sender
{
    if (sender.tag == 333) {//警务咨询
        
        HomeDetailVC *detailVC = [[HomeDetailVC alloc] init];
        detailVC.isADVC = 5;
        detailVC.detailStr = _newUrlStr;
        [self setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:detailVC animated:YES];
        [self setHidesBottomBarWhenPushed:NO];
        
    }else if (sender.tag == 334){//跳转官网新浪微博
        [self setHidesBottomBarWhenPushed:YES];
        HomeDetailVC *detailVC = [[HomeDetailVC alloc] init];
        detailVC.isADVC = 4;
        [self.navigationController pushViewController:detailVC animated:YES];
        [self setHidesBottomBarWhenPushed:NO];

    }else if (sender.tag == 335){//分享
        [self didShareSDK];
    }
    
}

- (void)didShareSDK
{
    //1、创建分享参数
    NSArray* imageArray = @[[UIImage imageNamed:@"shareLogo.jpg"]];
    if (imageArray) {
        
        NSMutableDictionary *shareParams = [NSMutableDictionary dictionary];
        
        NSString *welcomStr = @"欢迎了解平安龙江";
        NSString *downloadUrlStr = @"http://gafw.hljga.gov.cn/xzzx.do?method=show";
        
        [shareParams SSDKSetupShareParamsByText:welcomStr
                                         images:imageArray
                                            url:[NSURL URLWithString:downloadUrlStr]
                                          title:@"平安龙江"
                                           type:SSDKContentTypeAuto];
        
        [shareParams SSDKEnableUseClientShare];
        
        //2、分享（可以弹出我们的分享菜单和编辑界面）
        [ShareSDK showShareActionSheet:nil items:nil shareParams:shareParams onShareStateChanged:^(SSDKResponseState state, SSDKPlatformType platformType, NSDictionary *userData, SSDKContentEntity *contentEntity, NSError *error, BOOL end){

            //如果是新浪分享，重新编辑字典，带上下载的网址
            if (platformType == SSDKPlatformTypeSinaWeibo) {
                [shareParams SSDKSetupShareParamsByText:[NSString stringWithFormat:@"%@:%@\n", welcomStr, downloadUrlStr]
                                                 images:imageArray
                                                    url:nil
                                                  title:@"平安龙江"
                                                   type:SSDKContentTypeAuto];
                }
            
            switch (state) {
                case SSDKResponseStateSuccess:{
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"分享成功"
                                                                        message:nil
                                                                       delegate:nil
                                                              cancelButtonTitle:@"确定"
                                                              otherButtonTitles:nil];
                    [alertView show];
                    break;
                }
                case SSDKResponseStateFail:{
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"分享失败"
                                                                    message:[NSString stringWithFormat:@"%@",error]
                                                                   delegate:nil
                                                          cancelButtonTitle:@"OK"
                                                          otherButtonTitles:nil, nil];
                    [alert show];
                    break;
                }
                default:
                    break;
            }
        }
    ];}

}

@end
