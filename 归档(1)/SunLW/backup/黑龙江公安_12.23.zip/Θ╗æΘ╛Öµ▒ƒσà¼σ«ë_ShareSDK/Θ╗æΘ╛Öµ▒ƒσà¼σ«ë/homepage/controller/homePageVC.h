//
//  homePageVC.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTabbarBtn.h"

@interface homePageVC : UIViewController
@property (nonatomic, strong) MyTabbarBtn *itemBtn;

@end
