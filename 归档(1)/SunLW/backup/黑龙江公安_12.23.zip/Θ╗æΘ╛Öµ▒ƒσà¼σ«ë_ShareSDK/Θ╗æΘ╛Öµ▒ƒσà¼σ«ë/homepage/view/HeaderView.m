//
//  HeaderView.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/17.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "HeaderView.h"

@implementation HeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        self.titleLab = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, self.frame.size.width-10, self.frame.size.height)];
        self.titleLab.backgroundColor = [UIColor whiteColor];
        [self addSubview:self.titleLab];
    }
    
    return self;
    
}

@end
