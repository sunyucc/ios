//
//  HomeCell.m
//  黑龙江公安
//
//  Created by Xyao on 16/11/17.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "HomeCell.h"

@implementation HomeCell
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self createCell];
    }
    return self;
}

- (void)createCell
{
    CGFloat cellW = self.contentView.frame.size.width;
    CGFloat cellH = self.contentView.frame.size.height;

    self.backgroundColor = [UIColor whiteColor];
    
    //图片
    self.iconView = [[UIImageView alloc] initWithFrame:CGRectMake(cellW/8*3, cellH/5, cellW/4, cellW/4)];
    [self.contentView addSubview:self.iconView];
    
    //标题
    self.titleLab = [[UILabel alloc] initWithFrame:CGRectMake(10, cellH/5*3, cellW-20, 20)];
    self.titleLab.textColor = [UIColor blackColor];
    self.titleLab.textAlignment = NSTextAlignmentCenter;
    self.titleLab.font = [UIFont systemFontOfSize:14];
    [self.contentView addSubview:self.titleLab];

    //上下左右4个边框
    self.topLine = [[UIView alloc] initWithFrame:CGRectMake(0, 0, cellW+2, 1)];
    self.topLine.hidden = NO;
    self.topLine.backgroundColor = [UIColor colorWithRed:220/255.f green:220/255.f blue:220/255.f alpha:1];
    [self.contentView addSubview:self.topLine];

    self.bottomLine = [[UIView alloc] initWithFrame:CGRectMake(-2, cellH, cellW+2, 1)];
    self.bottomLine.hidden = NO;
    self.bottomLine.backgroundColor = [UIColor colorWithRed:220/255.f green:220/255.f blue:220/255.f alpha:1];
    [self.contentView addSubview:self.bottomLine];

    
    self.leftLine = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, cellH)];
    self.leftLine.hidden = YES;
    _leftLine.backgroundColor = [UIColor colorWithRed:220/255.f green:220/255.f blue:220/255.f alpha:1];
    [self.contentView addSubview:self.leftLine];
    
    self.rightLine = [[UIView alloc] initWithFrame:CGRectMake(cellW-1, 0, 1, cellH)];
    self.rightLine.hidden = YES;
    self.rightLine.backgroundColor = [UIColor colorWithRed:220/255.f green:220/255.f blue:220/255.f alpha:1];
    [self.contentView addSubview:self.rightLine];

    
}

- (void)setBounds:(CGRect)bounds {
    [super setBounds:bounds];
    self.contentView.frame = bounds;
}


@end
