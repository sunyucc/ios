//
//  ADPhotoModel.h
//  黑龙江公安
//
//  Created by Xyao on 16/11/15.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ADPhotoModel : NSObject
/*
 轮播图片model，对应json数据的各个数据
 */
@property (nonatomic) NSString *xwid;
@property (nonatomic) NSString *tplj;
@property (nonatomic) NSString *xwdz;
@property (nonatomic) NSString *sfgd;
@property (nonatomic) NSString *scbj;
@property (nonatomic) NSString *cjsj;
@property (nonatomic) NSString *gxsj;
@property (nonatomic) NSString *xwmc;

@end
