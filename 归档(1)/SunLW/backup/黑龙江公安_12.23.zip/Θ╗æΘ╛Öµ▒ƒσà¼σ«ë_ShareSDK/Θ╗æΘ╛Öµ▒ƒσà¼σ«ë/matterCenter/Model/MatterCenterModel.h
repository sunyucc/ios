//
//  MatterCenterModel.h
//  黑龙江公安
//
//  Created by administrator on 16/11/23.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MatterCenterModel : NSObject

//"sxid": 10152,
//"sxmc": "损坏异地换领居民身份证",
//"sxywdl": "01",
//"sxfwlx": "02",
//"sxywlb": "01",
//"zn": "Y",
//"yy": "Y",
//"sb": "",
//"zdBsckid": "101201",
//"scbj": "n",
//"gxsj": "",
//"cjsj": "2016-11-14",
//"djs": 149

@property (nonatomic, copy) NSString *sxid;
@property (nonatomic, copy) NSString *sxmc;
@property (nonatomic, copy) NSString *sxywdl;
@property (nonatomic, copy) NSString *sxfwlx;
@property (nonatomic, copy) NSString *sxywlb;
@property (nonatomic, copy) NSString *zn;
@property (nonatomic, copy) NSString *yy;
@property (nonatomic, copy) NSString *sb;
@property (nonatomic, copy) NSString *zdBsckid;
@property (nonatomic, copy) NSString *scbj;
@property (nonatomic, copy) NSString *gxsj;
@property (nonatomic, copy) NSString *cjsj;
@property (nonatomic, copy) NSString *djs;


@end
