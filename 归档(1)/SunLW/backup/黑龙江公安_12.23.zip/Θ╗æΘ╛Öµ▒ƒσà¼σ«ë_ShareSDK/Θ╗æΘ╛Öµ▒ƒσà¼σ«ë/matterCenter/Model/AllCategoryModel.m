//
//  AllCategoryModel.m
//  黑龙江公安
//
//  Created by administrator on 16/11/23.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "AllCategoryModel.h"

@implementation AllCategoryModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
