//
//  MatterCenterModel.m
//  黑龙江公安
//
//  Created by administrator on 16/11/23.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "MatterCenterModel.h"

@implementation MatterCenterModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
