//
//  MatterCollectionCell.h
//  黑龙江公安
//
//  Created by administrator on 16/11/23.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MatterCollectionCell : UICollectionViewCell

@property (nonatomic, strong) UILabel *titleLab;

@property (nonatomic, strong) UIButton *selectBtn;

@end
