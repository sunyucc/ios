//
//  MatterCenterVC.m
//  黑龙江公安
//
//  Created by administrator on 16/11/23.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import "MatterCenterVC.h"
#import "MyAFNet.h"
#import "MJRefresh.h"

#import "MatterCenterModel.h"
#import "AllCategoryModel.h"

#import "HomeDetailVC.h"

#import "MatterCollectionCell.h"

@interface MatterCenterVC () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, UICollectionViewDelegate, UICollectionViewDataSource, UIScrollViewDelegate>

{
    UITableView *_tableView;
    NSMutableArray *_tabDataArr;
    NSMutableArray *_cellHeightArr;
    
    UICollectionView *_collectionView;
    NSMutableArray *_collectDataArr;
    NSMutableDictionary *_collectionDict;
    
    NSString *_policeCategoryStr;
    NSString *_personCategoryStr;
    NSString *_searchTFStr;
    
    int _page;
    
    UIButton *_allBtn;
    UIButton *_iconBtn;
    UITextField *_searchTF;
    
    MatterCollectionCell *_tmemCollectViewCell;
}

@end

@implementation MatterCenterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    _tabDataArr = [[NSMutableArray alloc] init];
    _cellHeightArr = [[NSMutableArray alloc] init];
    
    _tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
    _tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self setupTabHeaderView];
    [self.view addSubview:_tableView];
    
    
    _collectDataArr = [[NSMutableArray alloc] init];
    _collectionDict = [[NSMutableDictionary alloc] init];
    _policeCategoryStr = @"";
    _personCategoryStr = @"";
    _searchTFStr = @"";
    
    //创建一个layout布局类
    UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc]init];
    layout.minimumLineSpacing = 0; //行间距
    layout.minimumInteritemSpacing = 0;//列间距
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    layout.headerReferenceSize = CGSizeMake(0, 20);
    
    //初始化collectionView
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 64+40+15, sWidth, sHeight/2) collectionViewLayout:layout];
    _collectionView.hidden = YES;
    _collectionView.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1];
    _collectionView.delegate=self;
    _collectionView.dataSource=self;
    
    //注册cell
    [_collectionView registerClass:[MatterCollectionCell class] forCellWithReuseIdentifier:@"ColleciViewCell"];
    //注册头视图
    [_collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"CollectionViewHeader"];

    
    [self.view addSubview:_collectionView];

    _page = 1;
    [self getTableViewNetData];
    
    _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        _page = 1;
        [self getTableViewNetData];
    }];
    
    _tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        _page++;
        [self getTableViewNetData];
    }];
    
    [self getCollectionViewData];
    
}


#pragma mark -- collectionView delegate

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 2;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSArray *sectionArr = nil;
    if (section == 0) {
        sectionArr = _collectionDict[@"firstCollectionArr"];
        
    }else{
        sectionArr = _collectionDict[@"secondCollectionArr"];

    }
    return sectionArr.count;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    CGSize size = CGSizeMake(sWidth/3-3,35);
    return size;
}

// 设置section头视图的参考大小，与tableheaderview类似
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout
referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(sWidth, 30);
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"CollectionViewHeader" forIndexPath:indexPath];

    if (kind == UICollectionElementKindSectionHeader) {
        
        for (UIView *subView in headerView.subviews) {
            [subView removeFromSuperview];
        }
        
        UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(5, 3, sWidth, 25)];
        titleLab.font = [UIFont systemFontOfSize:15];
        if (indexPath.section == 0) {
            titleLab.text = @"警种";
        }else{
            titleLab.text = @"分类";
        }
        
        [headerView addSubview:titleLab];
    }
    
    return headerView;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    MatterCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ColleciViewCell" forIndexPath:indexPath];
    
    NSArray *sectionArr = nil;
    if (indexPath.section == 0) {
        cell.selectBtn.hidden = YES;
        sectionArr = _collectionDict[@"firstCollectionArr"];

    }else{
        sectionArr = _collectionDict[@"secondCollectionArr"];
    }
    
    
    
    if (indexPath.row == 0) {
        
        if (indexPath.section == 1) {
            cell.selectBtn.selected = YES;
            _tmemCollectViewCell = cell;
        }
        
        cell.titleLab.text = @"全部";
    }else{
        AllCategoryModel *model = sectionArr[indexPath.row];
        cell.titleLab.text = model.mc;
    }
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    
    NSArray *sectionArr = nil;
    
    if (indexPath.section == 0) {
        sectionArr = _collectionDict[@"firstCollectionArr"];
        if (indexPath.row == 0) {
            _policeCategoryStr = @"";
            
            [_allBtn setTitle:@"全部" forState:UIControlStateNormal];
            [_allBtn setTitle:@"全部" forState:UIControlStateSelected];

        }else{
            AllCategoryModel *model = sectionArr[indexPath.row];
            _policeCategoryStr = model.bm;
            [_allBtn setTitle:model.mc forState:UIControlStateNormal];
            [_allBtn setTitle:model.mc forState:UIControlStateSelected];
        }
        
        _allBtn.selected = YES;
        _iconBtn.selected = NO;
        _collectionView.hidden = YES;
        _page = 1;
        [self getTableViewNetData];
        
    }else{
        MatterCollectionCell *cell = (MatterCollectionCell *)[collectionView cellForItemAtIndexPath:indexPath];
        
        _tmemCollectViewCell.selectBtn.selected = NO;
        cell.selectBtn.selected = YES;
        _tmemCollectViewCell = cell;
        
        sectionArr = _collectionDict[@"secondCollectionArr"];
        if (indexPath.row == 0) {
            _personCategoryStr = @"";
        }else{
            AllCategoryModel *model = sectionArr[indexPath.row];
            _personCategoryStr = model.bm;
        }
    }
}

#pragma mark -- 获得网络数据
//获得事项中心数据
- (void)getTableViewNetData
{
    NSString *pageStr = [NSString stringWithFormat:@"%d", _page];
    //&sxmc=身份证&sxywdl=户政&sxywlb=全部
    NSDictionary *jsonDict = @{@"sxmc" : _searchTFStr,
                               @"sxywdl" : _policeCategoryStr,
                               @"sxywlb" : _personCategoryStr,};

    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:jsonDict options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    NSDictionary *parameters = @{@"pageIndex" : pageStr,
                                 @"pageSize" : @"20",
                                 @"json" : jsonStr};

    [MyAFNet postData:MatterCenter_Post_mainData parameters:parameters success:^(id responseObject) {
        
        if (_page == 1) {
            [_tabDataArr removeAllObjects];
            [_cellHeightArr removeAllObjects];
        }
        
        for (NSDictionary *dict in responseObject[@"data"]) {
            MatterCenterModel *model = [[MatterCenterModel alloc] init];
            [model setValuesForKeysWithDictionary:dict];
            
            [_tabDataArr addObject:model];
            
            CGSize titleSize = [model.sxmc boundingRectWithSize:CGSizeMake(sWidth, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15]} context:nil].size;
            NSString *cellHeightStr = [NSString stringWithFormat:@"%d", (int)titleSize.height];
            [_cellHeightArr addObject:cellHeightStr];
            
        }
        
        [_tableView.mj_header endRefreshing];
        [_tableView.mj_footer endRefreshing];
        
        [_tableView reloadData];
        
    } failure:^(NSError *error) {
        [_tableView.mj_header endRefreshing];
        [_tableView.mj_footer endRefreshing];
        
    }];

    [self.view endEditing:YES];
    
}
//get collectionView data 获得警种分类数据
- (void)getCollectionViewData
{
    dispatch_group_t dispatchGroup = dispatch_group_create();
    dispatch_group_enter(dispatchGroup);
    [MyAFNet getData:MatterCenter_Get_PolceData parameters:nil success:^(id responseObject) {
        
        NSMutableArray *firstSectionArr = [[NSMutableArray alloc] init];
        [firstSectionArr addObject:@"全部"];
        for (NSDictionary *dict in responseObject) {
            AllCategoryModel *model = [[AllCategoryModel alloc] init];
            [model setValuesForKeysWithDictionary:dict];
            [firstSectionArr addObject:model];
        }
        
        [_collectionDict setObject:firstSectionArr forKey:@"firstCollectionArr"];
        [_collectDataArr addObject:firstSectionArr];
        
        dispatch_group_leave(dispatchGroup);
        
    } failure:^(NSError *error) {
        
    }];
    
    dispatch_group_enter(dispatchGroup);
    [MyAFNet getData:MatterCenter_Get_CategoryData parameters:nil success:^(id responseObject) {
        
        NSMutableArray *secondSectionArr = [[NSMutableArray alloc] init];
        [secondSectionArr addObject:@"全部"];
        for (NSDictionary *dict in responseObject) {
            AllCategoryModel *model = [[AllCategoryModel alloc] init];
            [model setValuesForKeysWithDictionary:dict];
            [secondSectionArr addObject:model];
        }
        [_collectionDict setObject:secondSectionArr forKey:@"secondCollectionArr"];
        
        [_collectDataArr addObject:secondSectionArr];
        
        dispatch_group_leave(dispatchGroup);
        
    } failure:^(NSError *error) {
        
    }];
    
    dispatch_group_notify(dispatchGroup, dispatch_get_main_queue(), ^(){
        
        NSArray *firstArr = _collectionDict[@"firstCollectionArr"];
        NSArray *secondArr = _collectionDict[@"secondCollectionArr"];

        double hang1 = firstArr.count/3.0;
        double hang2 = secondArr.count/3.0;
        int hang11 = ceil(hang1);
        int hang22 = ceil(hang2);
        
        int sum = hang11 + hang22;
        
        //根据请求结果，动态改变collecitonView的高度
        CGRect frame = _collectionView.frame;
        frame.size.height = sum * (35) + 61;
        _collectionView.frame = frame;
        
        [_collectionView reloadData];
    });
    
}

#pragma mark -- 设置头view，就是搜索和全部按钮
- (void)setupTabHeaderView
{
    //新建两个view，为了显示搜索框上面的空白区域
    UIView *bigView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, sWidth, 60)];
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 15, sWidth, 40)];
    [bigView addSubview:headerView];
    
    headerView.layer.borderWidth = 1;
    headerView.layer.masksToBounds = YES;
    headerView.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    headerView.layer.cornerRadius = 5;
    
    _allBtn = [[UIButton alloc]  initWithFrame:CGRectMake(0, 0, 80, 40)];
    _allBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    _allBtn.selected = YES;
    [_allBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_allBtn setTitle:@"全部" forState:UIControlStateNormal];
    [_allBtn setTitle:@"全部" forState:UIControlStateSelected];
    [_allBtn addTarget:self action:@selector(allBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [headerView addSubview:_allBtn];
    
    _iconBtn = [[UIButton alloc] initWithFrame:CGRectMake(80, 10, 20, 20)];
    _iconBtn.selected = NO;
    [_iconBtn setImage:[UIImage imageNamed:@"sanJiao_dao"] forState:UIControlStateNormal];
    [_iconBtn setImage:[UIImage imageNamed:@"sanJiao_zheng"] forState:UIControlStateSelected];
    [_iconBtn addTarget:self action:@selector(allBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [headerView addSubview:_iconBtn];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(99, 10, 1, 20)];
    lineView.backgroundColor = [UIColor lightGrayColor];
    [headerView addSubview:lineView];
    
    _searchTF = [[UITextField alloc] initWithFrame:CGRectMake(100, 0, sWidth-160, 40)];
    _searchTF.font = [UIFont systemFontOfSize:16];
    _searchTF.clearButtonMode = UITextFieldViewModeWhileEditing;
    _searchTF.placeholder = @" 请输入事项名称";
    _searchTF.delegate = self;
    _searchTF.textColor = [UIColor blackColor];
    [headerView addSubview:_searchTF];
    
    UIButton *searchBtn = [[UIButton alloc] initWithFrame:CGRectMake(sWidth-60, 0, 60, 40)];
    searchBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    searchBtn.backgroundColor = [UIColor colorWithRed:76/255.f green:175/255.f blue:80/255.f alpha:1];
    [searchBtn addTarget:self action:@selector(searchBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [searchBtn setTitle:@"搜索" forState:UIControlStateNormal];
    [headerView addSubview:searchBtn];
    
    _tableView.tableHeaderView = bigView;
}

#pragma mark -- 全部按钮和搜索按钮点击
- (void)allBtnClick:(UIButton *)sender
{
    if (sender == _allBtn) {
        
        if (sender.selected) {
            _collectionView.hidden = NO;
            _iconBtn.selected = YES;
        }else{
            _collectionView.hidden = YES;
            _iconBtn.selected = NO;
        }
        sender.selected = !sender.selected;
    }
    

}

//搜索按钮的点击
- (void)searchBtnClick
{
    _allBtn.selected = YES;
    _collectionView.hidden = YES;
    [self.view endEditing:YES];
    [self getTableViewNetData];
}

#pragma mark -- tableView  delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _tabDataArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    NSString *cellHeightStr = _cellHeightArr[indexPath.row];
    return cellHeightStr.integerValue + 30;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"matterCenterCell"];
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"matterCenterCell"];
        cell.textLabel.font = [UIFont systemFontOfSize:16];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.textLabel.numberOfLines =0;
    }
    
    MatterCenterModel *model = _tabDataArr[indexPath.row];
    cell.textLabel.text = model.sxmc;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [self.view endEditing:YES];
    _collectionView.hidden = YES;
    _allBtn.selected = YES;
    _iconBtn.selected = NO;
    
    MatterCenterModel *model = _tabDataArr[indexPath.row];
    
    HomeDetailVC *detailVC = [[HomeDetailVC alloc] init];
    detailVC.matterModel = model;
    detailVC.isADVC = 3;
    detailVC.detailStr = self.detailStr; //url传给下一级页面
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:detailVC animated:YES];
    self.hidesBottomBarWhenPushed = NO;
}

#pragma mark -- 退出键盘
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    _searchTFStr = textField.text;
}

#pragma mark -- scroll deltage
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
    _collectionView.hidden = YES;
    _allBtn.selected = YES;
    _iconBtn.selected = NO;
}

@end
