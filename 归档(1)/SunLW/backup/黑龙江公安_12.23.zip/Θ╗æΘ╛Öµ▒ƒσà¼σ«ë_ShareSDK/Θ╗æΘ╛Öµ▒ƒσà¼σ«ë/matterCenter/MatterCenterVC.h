//
//  MatterCenterVC.h
//  黑龙江公安
//
//  Created by administrator on 16/11/23.
//  Copyright © 2016年 wdykqios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTabbarBtn.h"

@interface MatterCenterVC : UIViewController
@property (nonatomic, strong) MyTabbarBtn *itemBtn;

@property (nonatomic, copy) NSString *detailStr; //事项中心详情页面对应的H5页面的部分URL

@end
